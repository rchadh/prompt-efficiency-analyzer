# Agent Governance Console — UI pack

| File | What it is |
|---|---|
| `console-mockups.html` | Eleven screens, clickable and interactive. Open in any browser — no server, no build step. |
| `aimp-data-dictionary.xlsx` | 27 tables, 357 columns, generated from a live PostgreSQL 16 instance. |
| `screenshots/` | PNG of each screen, wizard step and variant. |
| `sql/` | The eleven migrations. Apply in filename order. |

## Where to find things

Grant terms are set on **step 3** of Request access, not on step 2. Step 2 is
browse-and-select; step 3 renders one card per selected item with the terms that
item's grant table needs. So the model budget and rate limits live there, as does a
prompt's role and a memory store's access mode. Each step-2 tab now says what will
be asked for next.

## Screens, by the phase each serves

| Screen | Phase | Who uses it |
|---|---|---|
| Browse catalogue | 0, 4 | Consumer team, platform |
| Register MCP and tools | 0 | Platform team |
| Register a resource | 0, 3 | Platform team, consumer team |
| Consumer onboarding | 1 | Platform administrator |
| Register an agent | 2 | Consumer team |
| Agent workspace | 2, 3, 6 | Consumer team |
| Request access | 4 | Consumer team |
| Approval queue | 4 | Platform team, data owner |
| Attestation | Steady state | Accountable owner |
| Drift and findings | Steady state | Platform team |
| Impact analysis | Steady state | Platform team, risk |

Phase 5 has no screen by design — it is the automated apply-and-project step.

## Grant terms by resource type

Why the grant tables are separate rather than one polymorphic table:

| Resource type | Extra grant terms | Lands in |
|---|---|---|
| Tool | follow non-breaking versions | `agent_tool_grant` |
| MCP server | none — warn it reaches every tool on the server, now and later | `agent_mcp_grant` |
| Prompt | role (system, task, tool_selection, other) | `agent_prompt_grant` |
| Model route | monthly budget, requests per minute, tokens per minute | `agent_model_grant` |
| Guardrail | none — platform baselines are attached, not requested | `agent_guardrail_binding` |
| Memory store | access mode (read_write, read_only) | `agent_memory_binding` |

Terms are captured in `change_request_item.payload` and unpack into the matching
grant table on approval.

## Model spend — designed but not fully built

Captured today on `agent_model_grant`: `monthly_budget_usd`, `rpm_limit`, `tpm_limit`,
`litellm_virtual_key_id`, plus the approver and timestamp. Limits are per agent **per
route**, so an agent on two models has two budgets and no field states its combined
total.

Not yet in the schema, and needed:

- `consumer.monthly_budget_ceiling_usd` — spend has no ceiling above it the way
  classification has `consumer.clearance`. Without it a team can allocate any number.
- `on_budget_exhausted` (block / alert_only / degrade), `degrade_to_route_id`,
  `alert_threshold_pct` — nothing currently says what happens when a cap is hit.
- Account-level throughput tracking. The sum of every agent's TPM will exceed the
  Bedrock account quota long before any single agent looks unreasonable.

Not yet built at all:

- The LiteLLM projection worker. The outbox row is written by trigger; nothing drains
  it. It needs `/key/generate`, `/key/update` and `/key/delete`, and a decision on
  whether a key is per agent or per agent-route pair — LiteLLM attaches a budget to a
  key, so per-route budgets cannot both be enforced on one key.
- Spend read-back. The database knows allocation; LiteLLM knows consumption. Nothing
  reads it back, so "which agents are near their cap" is unanswerable from the console.
- Value-level reconciliation. The nightly job would catch a missing virtual key but not
  one whose budget was edited directly in the LiteLLM admin UI.

## How a tool reaches the catalogue

Tool rows are **derived from a gateway target's own schema, never typed in**. The only
human input is classification. Four routes reach the same ingest service: push from the
API team's pipeline, nightly pull from the spec registry, gateway reconciliation, and
the manual screen. An operation with no classification is blocked, because no default
is safe. Lambda and Smithy targets have no OpenAPI document, so the schema is read from
the gateway's `tools/list` response instead.

## The colour rule

Colour carries exactly one meaning: data classification. The bar down the left of each
row and every chip use the same ramp — PUBLIC, INTERNAL, PII, NPI, MNPI, cool through
warm. Nothing else is coloured, so sensitivity is readable without reading any text.

## Four things the UI must get right

**Set `app.actor` on every transaction.** The audit trigger reads it. Without it,
`entity_history` records a null actor and the audit trail is worthless.

**Disable, don't error.** Self-approval, above-clearance grants, DRAFT versions, shared
Entra registrations and mandatory guardrails at a bypassable enforcement point are all
refused by database constraints. Surface them as disabled controls, not as a 500.

**Never persist a form value that should be verified.** Entra registrations are
confirmed against Graph; prompts, guardrails and memory stores against their provider;
tool contracts against the schema. The database stores what was read back.

**Never write to Neptune or LiteLLM from the UI.** Every mutation goes through the
onboarding API. Projections are handled by the outbox worker.

## Naming to settle before build

The nav says "Change request", the page heading says "Request access", the workbook says
"Request access (change request)". Pick one — an action should keep the same name through
the whole flow.

## Not yet specified

- Empty, loading and error states for each screen
- Revoking a grant outside attestation
- Agent version promotion and what happens to the previous version's grants
- Runtime ARN capture mechanism (tag at deploy, EventBridge, verify, reconcile)
- Registration segregation by owner scope (private / shared / platform)
- Neptune projection shape, bundle JSON schema, IGA export contract
