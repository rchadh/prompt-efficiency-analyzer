-- 11_extensions.sql
-- Additions agreed after the initial schema: provider-agnostic guardrails,
-- spec-drift ingestion, and memory stores as first-class onboarded resources.
set search_path to platform, public;

----------------------------------------------------------------------
-- Guardrails become provider-agnostic.
-- Identity and governance stay typed; vendor parameters move to JSON,
-- because the provider's API shape is not ours to model and varies.
----------------------------------------------------------------------
alter table guardrail
  add column provider          text not null default 'bedrock'
    check (provider in ('bedrock','presidio','lakera','custom','generic_api')),
  add column provider_ref      jsonb not null default '{}'::jsonb,
  add column apply_mode        text not null default 'pre_call'
    check (apply_mode in ('pre_call','post_call','during_call','pre_and_post')),
  add column on_violation      text not null default 'block'
    check (on_violation in ('block','mask','log_only')),
  add column enforcement_point text not null default 'model_gateway'
    check (enforcement_point in ('model_gateway','tool_gateway','agent_runtime','memory_write')),
  add column aws_region        text,
  add column policy_config     jsonb,
  add column policy_hash       text,
  add column verified_at       timestamptz;

-- Migrate the Bedrock-specific columns into provider_ref, then drop them.
update guardrail
   set provider_ref = jsonb_build_object(
         'guardrail_id', bedrock_guardrail_id,
         'version',      bedrock_guardrail_version)
 where provider = 'bedrock';

-- Views reference the old columns, so drop and rebuild them around provider_ref.
drop view if exists v_attestation_feed;
drop view if exists v_agent_entitlements;

alter table guardrail
  drop column bedrock_guardrail_id,
  drop column bedrock_guardrail_version;

alter table guardrail
  add constraint guardrail_provider_ref_shape check (
    case provider
      when 'bedrock' then provider_ref ? 'guardrail_id' and provider_ref ? 'version'
      when 'custom'  then provider_ref ? 'class_path'
      else true
    end
  );

-- A platform-mandated guardrail must be enforced server-side, never left
-- to the agent to pass on its own model call.
alter table guardrail
  add constraint guardrail_mandatory_enforcement check (
    not is_mandatory or enforcement_point in ('model_gateway','tool_gateway')
  );

----------------------------------------------------------------------
-- Tool contract document, so a hash mismatch can be explained
----------------------------------------------------------------------
alter table tool
  add column normalised_contract jsonb,
  add column contract_s3_uri     text,
  add column normaliser_version  text;

----------------------------------------------------------------------
-- Spec ingestion and drift detection
----------------------------------------------------------------------
create table spec_source (
  id             uuid primary key default gen_random_uuid(),
  env            text not null references environment(code),
  backing_api    text not null,
  source_type    text not null check (source_type in ('push','registry_pull','gateway')),
  source_uri     text,
  last_seen_at   timestamptz,
  last_etag      text,
  last_spec_hash text,
  normaliser_version text not null,
  is_active      boolean not null default true,
  created_at     timestamptz not null default now(),
  created_by     text not null,
  unique (env, backing_api, source_type)
);

create table tool_change_proposal (
  id            uuid primary key default gen_random_uuid(),
  env           text not null references environment(code),
  tool_id       uuid,
  backing_api   text not null,
  detected_by   text not null check (detected_by in ('push','registry_pull','gateway')),
  old_hash      text,
  new_hash      text not null,
  change_kind   text not null
                  check (change_kind in ('non_breaking','breaking','new_tool','removed_tool')),
  diff          jsonb not null,
  status        text not null default 'open'
                  check (status in ('open','auto_applied','approved','rejected','superseded')),
  sla_due_at    timestamptz,
  detected_at   timestamptz not null default now(),
  decided_by    text,
  decided_at    timestamptz,
  decision_note text,
  foreign key (tool_id, env) references tool (id, env)
);

create index tool_change_proposal_open_idx
  on tool_change_proposal (env, sla_due_at) where status = 'open';

----------------------------------------------------------------------
-- Memory stores: the only component that persists customer data
----------------------------------------------------------------------
create table memory_store (
  id                    uuid primary key default gen_random_uuid(),
  env                   text not null references environment(code),
  urn                   text not null unique,
  domain                text not null,
  name                  text not null,
  memory_arn            text,
  memory_id             text,
  strategy              text not null
                          check (strategy in ('short_term','semantic','summarisation','user_preference')),
  namespace_template    text not null,
  classification_ceiling text not null references data_classification(code),
  retention_days        integer check (retention_days > 0),
  legal_hold            boolean not null default false,
  deletion_contact      text,
  state                 lifecycle_state not null default 'draft',
  created_at            timestamptz not null default now(),
  created_by            text not null,
  updated_at            timestamptz not null default now(),
  unique (env, domain, name),
  unique (id, env)
);

create table agent_memory_binding (
  id           uuid primary key default gen_random_uuid(),
  env          text not null references environment(code),
  agent_id     uuid not null,
  memory_store_id uuid not null,
  access_mode  text not null default 'read_write'
                 check (access_mode in ('read_write','read_only')),
  change_request_id uuid references change_request(id),
  approved_by  text,
  approved_at  timestamptz,
  valid_from   timestamptz not null default now(),
  revoked_at   timestamptz,
  revoked_by   text,
  created_at   timestamptz not null default now(),
  created_by   text not null,
  foreign key (agent_id,        env) references agent        (id, env),
  foreign key (memory_store_id, env) references memory_store (id, env)
);

create unique index agent_memory_binding_active_uk
  on agent_memory_binding (agent_id, memory_store_id) where revoked_at is null;

----------------------------------------------------------------------
-- Reconciliation now spans Bedrock and the gateway too
----------------------------------------------------------------------
alter table reconciliation_finding
  drop constraint reconciliation_finding_target_check;
alter table reconciliation_finding
  add constraint reconciliation_finding_target_check
  check (target in ('neptune','litellm','bedrock','gateway'));

----------------------------------------------------------------------
-- Mandatory guardrail coverage: should always be empty
----------------------------------------------------------------------
create or replace view v_missing_mandatory_guardrail as
select a.env, a.urn as agent_urn, g.urn as guardrail_urn
from agent a
cross join guardrail g
where a.state = 'active'
  and g.state = 'active'
  and g.is_mandatory
  and g.env = a.env
  and not exists (
    select 1 from agent_guardrail_binding b
     where b.agent_id = a.id and b.guardrail_id = g.id and b.revoked_at is null
  );

----------------------------------------------------------------------
-- Memory stores whose declared ceiling is below the tools their
-- bound agents can reach
----------------------------------------------------------------------
create or replace view v_memory_classification_drift as
select m.urn as memory_urn, m.classification_ceiling, a.urn as agent_urn,
       max(dct.rank) as max_tool_rank, dcm.rank as ceiling_rank
from memory_store m
join agent_memory_binding b on b.memory_store_id = m.id and b.revoked_at is null
join agent a on a.id = b.agent_id
join data_classification dcm on dcm.code = m.classification_ceiling
join agent_tool_grant tg on tg.agent_id = a.id and tg.revoked_at is null
join tool t on t.id = tg.tool_id
join data_classification dct on dct.code = t.classification
group by m.urn, m.classification_ceiling, a.urn, dcm.rank
having max(dct.rank) > dcm.rank;

-- Rebuild the entitlement view with provider-agnostic guardrail references.
create or replace view v_agent_entitlements as
select a.env, a.id as agent_id, a.urn as agent_urn, c.urn as consumer_urn,
       'tool'::text as resource_type, t.urn as resource_urn, t.id as resource_id,
       t.gateway_alias as runtime_ref, t.contract_hash as pinned_ref,
       g.classification_at_grant as classification,
       g.valid_from, g.expires_at, g.last_attested_at
from agent_tool_grant g
join agent a on a.id = g.agent_id
join consumer c on c.id = a.consumer_id
join tool t on t.id = g.tool_id
where g.revoked_at is null and (g.expires_at is null or g.expires_at > now())

union all
select a.env, a.id, a.urn, c.urn,
       'mcp_server', m.urn, m.id,
       m.target_name, m.gateway_id,
       null, g.valid_from, g.expires_at, g.last_attested_at
from agent_mcp_grant g
join agent a on a.id = g.agent_id
join consumer c on c.id = a.consumer_id
join mcp_server m on m.id = g.mcp_server_id
where g.revoked_at is null and (g.expires_at is null or g.expires_at > now())

union all
select a.env, a.id, a.urn, c.urn,
       'prompt', p.urn, p.id,
       p.bedrock_prompt_arn, p.bedrock_prompt_version,
       null, g.valid_from, null, g.last_attested_at
from agent_prompt_grant g
join agent a on a.id = g.agent_id
join consumer c on c.id = a.consumer_id
join prompt p on p.id = g.prompt_id
where g.revoked_at is null

union all
select a.env, a.id, a.urn, c.urn,
       'model_route', m.urn, m.id,
       m.name, m.upstream_model_id,
       m.max_classification, g.valid_from, null, g.last_attested_at
from agent_model_grant g
join agent a on a.id = g.agent_id
join consumer c on c.id = a.consumer_id
join model_route m on m.id = g.model_route_id
where g.revoked_at is null

union all
select a.env, a.id, a.urn, c.urn,
       'guardrail', gr.urn, gr.id,
       gr.provider, gr.provider_ref #>> '{version}',
       null, b.valid_from, null, null
from agent_guardrail_binding b
join agent a on a.id = b.agent_id
join consumer c on c.id = a.consumer_id
join guardrail gr on gr.id = b.guardrail_id
where b.revoked_at is null

union all
select a.env, a.id, a.urn, c.urn,
       'memory_store', ms.urn, ms.id,
       ms.memory_id, ms.namespace_template,
       ms.classification_ceiling, b.valid_from, null, null
from agent_memory_binding b
join agent a on a.id = b.agent_id
join consumer c on c.id = a.consumer_id
join memory_store ms on ms.id = b.memory_store_id
where b.revoked_at is null;

create or replace view v_attestation_feed as
select e.env, e.consumer_urn, o.upn as attester_upn, e.agent_urn,
       e.resource_type, e.resource_urn, e.classification,
       e.valid_from as granted_at, e.last_attested_at
from v_agent_entitlements e
join consumer c       on c.urn = e.consumer_urn
join consumer_owner o on o.consumer_id = c.id and o.role = 'accountable_owner';
